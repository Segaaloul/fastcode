import React, { useState, useEffect } from 'react';
import { Lock, Home, ArrowLeft, Shield, AlertTriangle, Wifi } from 'lucide-react';

function App() {
  const [isVisible, setIsVisible] = useState(false);
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; delay: number }>>([]);

  useEffect(() => {
    setIsVisible(true);
    
    // Generate random particles for background animation
    const newParticles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 3
    }));
    setParticles(newParticles);
  }, []);

  const handleRetry = () => {
    // Simulate retry action
    window.location.reload();
  };

  const handleGoHome = () => {
    // Simulate navigation to home
    window.history.back();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden flex items-center justify-center">
      {/* Animated Background Particles */}
      <div className="absolute inset-0 overflow-hidden">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className={`absolute w-2 h-2 rounded-full animate-pulse ${
              particle.id % 3 === 0 ? 'bg-green-400/20' : 
              particle.id % 3 === 1 ? 'bg-purple-400/20' : 'bg-emerald-400/20'
            }`}
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              animationDelay: `${particle.delay}s`,
              animationDuration: '4s'
            }}
          />
        ))}
      </div>

      {/* Geometric Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 border border-green-500/20 rotate-45 animate-spin" style={{ animationDuration: '20s' }} />
        <div className="absolute bottom-1/4 right-1/4 w-24 h-24 border border-emerald-500/20 rotate-12 animate-pulse" />
        <div className="absolute top-1/2 left-1/6 w-16 h-16 bg-gradient-to-r from-green-600/10 to-emerald-600/10 rounded-full animate-bounce" style={{ animationDuration: '3s' }} />
      </div>

      {/* Main Content */}
      <div className={`relative z-10 max-w-md w-full mx-4 transition-all duration-1000 transform ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20">
          {/* Icon Section */}
          <div className="text-center mb-8">
            <div className="relative inline-block">
              <div className="absolute inset-0 bg-gradient-to-r from-red-500/20 to-green-500/20 rounded-full animate-ping" />
              <div className="relative bg-gradient-to-r from-red-500 via-orange-500 to-green-600 rounded-full p-6 animate-pulse">
                <Lock className="w-12 h-12 text-white" />
              </div>
            </div>
          </div>

          {/* Title and Message */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-4 animate-fade-in">
              Access Denied
            </h1>
            <div className="flex items-center justify-center mb-4">
              <AlertTriangle className="w-5 h-5 text-yellow-400 mr-2" />
              <span className="text-yellow-400 font-semibold">Error 403</span>
            </div>
            <p className="text-gray-300 text-lg leading-relaxed">
              You don't have permission to access this resource. Please contact your administrator or try again later.
            </p>
          </div>

          {/* Status Indicators */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="text-center">
              <Shield className="w-6 h-6 text-red-400 mx-auto mb-2" />
              <span className="text-xs text-gray-400">Security</span>
            </div>
            <div className="text-center">
              <Wifi className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
              <span className="text-xs text-gray-400">Connected</span>
            </div>
            <div className="text-center">
              <Lock className="w-6 h-6 text-green-400 mx-auto mb-2" />
              <span className="text-xs text-gray-400">Restricted</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-4">
            <button
              onClick={handleRetry}
              className="w-full bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 hover:from-green-700 hover:via-emerald-700 hover:to-teal-700 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-green-500/50"
            >
              Try Again
            </button>
            
            <button
              onClick={handleGoHome}
              className="w-full bg-white/10 hover:bg-white/20 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 border border-white/20 hover:border-white/40 focus:outline-none focus:ring-4 focus:ring-white/20 flex items-center justify-center space-x-2"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Go Back</span>
            </button>

            <button
              onClick={handleGoHome}
              className="w-full text-gray-400 hover:text-green-300 font-medium py-3 px-6 rounded-xl transition-all duration-300 hover:bg-green-500/10 flex items-center justify-center space-x-2"
            >
              <Home className="w-5 h-5" />
              <span>Return Home</span>
            </button>
          </div>

          {/* Footer */}
          <div className="mt-8 pt-6 border-t border-white/10 text-center">
            <p className="text-gray-500 text-sm">
              Need help? Contact support at{' '}
              <a href="mailto:support@company.com" className="text-green-400 hover:text-green-300 transition-colors duration-200 underline">
                support@company.com
              </a>
            </p>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute -top-4 -right-4 w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full opacity-60 animate-bounce" style={{ animationDelay: '1s' }} />
        <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-gradient-to-r from-teal-500 to-green-500 rounded-full opacity-60 animate-bounce" style={{ animationDelay: '2s' }} />
      </div>

      {/* Additional CSS for custom animations */}
      <style jsx>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fade-in {
          animation: fade-in 0.8s ease-out forwards;
        }
      `}</style>
    </div>
  );
}

export default App;